#include <stdlib.h>
#include <stdio.h>
#include "heap.h"
#include <string.h>

///Heap structure

struct heap{
    ///Integer Variable to save the value
    int value;
    ///heap_t pointer to the left child
    heap_t *left;
    ///heap_t pointer to the right child
    heap_t *right;
};

///Error structure
struct error{
    ///Pointer to char to save a string
    char *error_log;
};

///This function creates the root of the heap,
/// It also calls the insert Function which calls the create entry function which initializes the heap object
/// \param val is the value which the root of the heap holds
/// \return a pointer to an heap_t object
heap_t *createHeap(int val){
    heap_t *new = NULL;
    new = insert_recursive(new, val);
    return new;
}

///This function initializes the error struct
///
/// \return a pointer to an error_t object
error_t *create_error(){
    error_t *new = (error_t *) malloc(sizeof(error_t));
    return new;
}

///This function checks if the heap is empty
///
/// \param root a is the pointer to the root of the heap
/// \return 1 if empty and 0 if not empty
int is_empty(heap_t *root){
    if (root == NULL)
        return 1;
    else
        return 0;
}

///This function creates an heap_t object
///
/// \param val is the value to be inserted into the new object
/// \return a pointer to the new heap_t object
heap_t *create_entry(int val){
    heap_t *new = (heap_t *) malloc(sizeof(heap_t));
    new->right = new->left = NULL;
    new->value = val;
    return new;
}

///This function inserts a value into the heap structure by looping recursively through the heap.
///It also calls the create_entry function to create a new entry
///
/// \param root is a pointer to the root of the heap
/// \param val is the value to be inserted into the new object
/// \return a root pointer which points to the same object as the parameter root. This is necessary for the sake of the recursion
heap_t *insert_recursive(heap_t *root, int val){
    if(root == NULL) {
        root = create_entry(val);
    }

    else if (val <= root->value){
        root->left = insert_recursive(root->left, val);
    } else{
        root->right = insert_recursive(root->right, val);
    }
    return root;
}

///This function will find the smallest value in the heap.
///This works by going down the left tree until root.left is Null.
/// If executed on an emtpy heap it will copy an error string to the error struct
///
/// \param root is a pointer to the root of the heap
/// \param error is a pointer to the error struct
/// \return 0 if the heap is empty.
/// \return the smallest value in the heap if heap is not empty
int minimum(heap_t *root, error_t *error){
    //If tree is empty
    if(is_empty(root)){
        char *temp = "Executed minimum on empty heap!";
        error->error_log = (char *) malloc(strlen(temp) + 1);
        strcpy(error->error_log, temp);
        return 0;
    }
    //Go left until as far as possible
    while (root->left != NULL){
        root = root->left;
    }
    return root->value;
}

///This function will find the biggest value in the heap.
///This works by going down the right tree until root.right is Null.
/// If executed on an emtpy heap it will copy an error string to the error struct
///
/// \param root is a pointer to the root of the heap
/// \param error is a pointer to the error struct
/// \return 0 if the heap is empty.
/// \return the biggest value in the heap if heap is not empty
int maximum(heap_t *root, error_t *error){
    //If tree is empty
    if(root == NULL){
        char *temp = "Executed maximum on empty heap!";
        error->error_log = (char *) malloc(strlen(temp) + 1);
        strcpy(error->error_log, temp);
        return 0;
    }
    //Go right until as far as possible
    while (root->right != NULL){
        root = root->right;
    }
    return root->value;
}


///This Function extracts the smallest value from the heap
///
/// \param root is a pointer to the root of the heap
/// \return an heap_t object.
///This is necessary because if the smallest value is the root of the heap
///a new root must be set in this case the right child of the original root
heap_t *extractMin(heap_t *root){
    if (root == NULL){
        return root;
    }
    //Copy of root
    heap_t *temp = root;
    //Copy of previous root
    heap_t *prev_root = NULL;

    while (temp->left != NULL){
        prev_root = temp;
        temp = temp->left;
    }

   //Only execute if root has a left child to prevent segmentation fault
   if(prev_root != NULL) {
       //If smallest entry has a bigger child than itself
       if (temp->right != NULL) {
           prev_root->left = temp->right;
       } else {
           prev_root->left = NULL;
       }
       free(temp);
       return root;
   } else{
       ///If the heap root holds the smallest value there a new root must be selected
       ///The new root of the heap is the right child of the original root
       ///If there is no right root NULL gets returned as the new root
       temp = root->right;
       free(root);
       return temp;
   }
}

///This function is the error function
///
/// \param error is a pointer to the error struct
/// \return a char pointer to the string of error struct object
char *getError(error_t *error){
    return error->error_log;
}

///This function prints the content of the heap to the screen from small to high.
///This is achieved by recursively looping through the heap from left to right
///
/// \param root is a pointer to the root of the heap
void to_screen_recursive(heap_t *root){
    if(is_empty(root)){
        return;
    }
    if(root->left != NULL){
        to_screen_recursive(root->left);
    }

    printf("%d\n", root->value);

    if(root->right != NULL){
        to_screen_recursive(root->right);
    }

}

///This function finds a given number in the heap.
///This is achieved by recursively looping through the heap.
///
/// \param root is a pointer to the root of the heap
/// \param val is the int value to be found in the heap
/// \return 1 if number is in the heap
/// \return 0 if number is not in the heap
int find_number(heap_t *root, int val){
    if(is_empty(root)){
        return 0;
    }
    else if(val == root->value){
        return 1;
    }
    else if(val < root->value){
        return find_number(root->left, val);
    }
    else{
        return find_number(root->right, val);
    }
}

///This function frees the reserved space by heap_t objects
///This is achieved by recursively looping through the heap.
///
/// \param root is a pointer to the root of the heap
void destroyHeap(heap_t *root){
    if(is_empty(root)){
        return;
    }
    if(root->left != NULL){
        destroyHeap(root->left);
    }
    if(root->right != NULL){
        destroyHeap(root->right);
    }
    free(root);
}

///This function frees the error_t object
void destroyError(error_t *error){
    free(error);
}



