var searchData=
[
  ['size_63',['size',['../structheap.html#a5bbb507292d7c47325df66148cc2e32f',1,'heap']]]
];
