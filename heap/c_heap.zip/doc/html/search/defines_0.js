var searchData=
[
  ['max_53',['MAX',['../main_8c.html#a392fb874e547e582e9c66a08a1f23326',1,'main.c']]]
];
