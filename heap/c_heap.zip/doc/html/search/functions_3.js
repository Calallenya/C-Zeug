var searchData=
[
  ['find_5fnumber_39',['find_number',['../heap_8c.html#a984f6f1ee84f0d50f45a030dbae4cb69',1,'find_number(heap_t *root, int val):&#160;heap.c'],['../heap_8h.html#a984f6f1ee84f0d50f45a030dbae4cb69',1,'find_number(heap_t *root, int val):&#160;heap.c']]]
];
