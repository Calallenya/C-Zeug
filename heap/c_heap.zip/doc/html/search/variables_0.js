var searchData=
[
  ['error_5flog_47',['error_log',['../structerror.html#a1d0bbad9101de10b6fe08d68a34e2b82',1,'error']]]
];
