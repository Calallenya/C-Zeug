var searchData=
[
  ['restore_5fheap_56',['restore_heap',['../heap_8txt.html#a78052d4897abc7d1982ce2b97a007766',1,'heap.txt']]]
];
