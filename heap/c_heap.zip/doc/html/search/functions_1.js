var searchData=
[
  ['destroyerror_36',['destroyError',['../heap_8c.html#ac2e6925470219621dd8d3b08b48e740d',1,'destroyError(error_t *error):&#160;heap.c'],['../heap_8h.html#ac2e6925470219621dd8d3b08b48e740d',1,'destroyError(error_t *error):&#160;heap.c']]],
  ['destroyheap_37',['destroyHeap',['../heap_8c.html#a2e35d14b39a3c09f73790018480e0668',1,'destroyHeap(heap_t *root):&#160;heap.c'],['../heap_8h.html#a2e35d14b39a3c09f73790018480e0668',1,'destroyHeap(heap_t *root):&#160;heap.c']]]
];
