#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "heap.h"
#include <time.h>
///This Implementation of a binary heap does not follow the standard min condition.
///This is because i have no idea on how to implement such a system.\n
///Instead this binary heap sorts small values to the left and bigger values to the right.\n
///This causes bigger values than the root itself to be placed underneath it.\n
///For Illustration (ONLY IN CODE CLEARLY VISIBLE):\n
///             60              root of the heap(Root can be any random number)\n
///       45         80         first level\n
///    30    50   70    85      second level\n
///   ....................      and so on\n


int main() {
    #define MAX 20
    //Initialize structs
    //root must be created manually
    heap_t *root = createHeap(4516);
    error_t *error = create_error();

    //create random seed
    time_t t = time(NULL);
    srand(t);

    //TEST DRIVER

    for(int i = 0;i < MAX;i++){
        insert_recursive(root, rand() % 20000);
    }


    //to_screen_recursive(root);

    //Save Minimum
    int min = minimum(root, error);
    //Extract min as long all duplicates of min and min itself got extracted
    while(find_number(root, min) == 1) {
        root = extractMin(root);
    }

    printf("\n");
    //to_screen_recursive(root);
    if(find_number(root, min) != 1){
        printf("\nAll %ds got extracted from the heap", min);
    }

    //Execute minimum with NULL
    minimum(NULL, error);
    printf("\n%s", getError(error));

    printf("\nMaximum int: %d", maximum(root, error));
    destroyHeap(root);
    destroyError(error);

    return 0;
}
